from policyholder import Policyholder
from product import Product
from payment import Payment

# Create products
product1 = Product(1, "Health Insurance", 500)
product1.create_product()

# Create policyholders
p1 = Policyholder(101, "Alice")
p2 = Policyholder(102, "Bob")

p1.register()
p2.register()

# Assign products
p1.add_product(product1)
p2.add_product(product1)

# Process payments
payment1 = Payment(p1, product1)
payment2 = Payment(p2, product1)

payment1.process_payment(500)
payment2.process_payment(500)

# Display details
p1.display_details()
p2.display_details()