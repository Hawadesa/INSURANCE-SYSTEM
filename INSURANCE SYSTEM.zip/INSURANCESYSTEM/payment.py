from datetime import datetime, timedelta

class Payment:
    def __init__(self, policyholder, product):
        self.policyholder = policyholder
        self.product = product
        self.due_date = datetime.now() + timedelta(days=30)
        self.paid = False

    def process_payment(self, amount):
        if amount >= self.product.price:
            self.paid = True
            self.policyholder.balance += amount
            print(f"Payment successful for {self.policyholder.name}")
        else:
            print("Insufficient payment.")

    def send_reminder(self):
        print(f"Reminder: Payment due for {self.policyholder.name} on {self.due_date.date()}")

    def apply_penalty(self):
        if not self.paid:
            penalty = self.product.price * 0.1
            self.policyholder.balance += penalty
            print(f"Penalty of {penalty} applied to {self.policyholder.name}")