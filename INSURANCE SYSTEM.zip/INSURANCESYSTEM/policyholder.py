class Policyholder:
    def __init__(self, policy_id, name, status="Active"):
        self.policy_id = policy_id
        self.name = name
        self.status = status
        self.products = []
        self.balance = 0

    def register(self):
        print(f"Policyholder {self.name} registered successfully.")

    def suspend(self):
        self.status = "Suspended"
        print(f"Policyholder {self.name} has been suspended.")

    def reactivate(self):
        self.status = "Active"
        print(f"Policyholder {self.name} has been reactivated.")

    def add_product(self, product):
        self.products.append(product)

    def display_details(self):
        print("\n--- Policyholder Details ---")
        print(f"ID: {self.policy_id}")
        print(f"Name: {self.name}")
        print(f"Status: {self.status}")
        print(f"Balance: {self.balance}")
        print("Products:")
        for p in self.products:
            print(f" - {p.name} ({p.price})")