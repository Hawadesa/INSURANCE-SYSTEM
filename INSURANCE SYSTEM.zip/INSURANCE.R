
# Policyholder Class

Policyholder <- function(policy_id, name, status = "Active") {
  structure(list(
    policy_id = policy_id,
    name = name,
    status = status,
    products = list(),
    balance = 0
  ), class = "Policyholder")
}

# Register
register <- function(self) UseMethod("register")

register.Policyholder <- function(self) {
  message(paste("Policyholder", self$name, "registered successfully."))
  return(self)
}

# Suspend
suspend <- function(self) UseMethod("suspend")

suspend.Policyholder <- function(self) {
  self$status <- "Suspended"
  message(paste("Policyholder", self$name, "has been suspended."))
  return(self)
}

# Reactivate
reactivate <- function(self) UseMethod("reactivate")

reactivate.Policyholder <- function(self) {
  self$status <- "Active"
  message(paste("Policyholder", self$name, "has been reactivated."))
  return(self)
}

# Add product
add_product <- function(self, product) UseMethod("add_product")

add_product.Policyholder <- function(self, product) {
  self$products <- c(self$products, list(product))
  return(self)
}

# Display details
display_details <- function(self) UseMethod("display_details")

display_details.Policyholder <- function(self) {
  cat("\n--- Policyholder Details ---\n")
  cat("ID:", self$policy_id, "\n")
  cat("Name:", self$name, "\n")
  cat("Status:", self$status, "\n")
  cat("Balance:", self$balance, "\n")
  cat("Products:\n")
  
  if (length(self$products) == 0) {
    cat("  None\n")
  } else {
    for (p in self$products) {
      cat(" -", p$name, "(", p$price, ")\n")
    }
  }
  
  invisible(self)
}

# Product Class

Product <- function(product_id, name, price, status = "Available") {
  structure(list(
    product_id = product_id,
    name = name,
    price = price,
    status = status
  ), class = "Product")
}

create_product <- function(self) UseMethod("create_product")

create_product.Product <- function(self) {
  message(paste("Product", self$name, "created successfully."))
  return(self)
}

update_product <- function(self, name = NULL, price = NULL) UseMethod("update_product")

update_product.Product <- function(self, name = NULL, price = NULL) {
  if (!is.null(name)) self$name <- name
  if (!is.null(price)) self$price <- price
  message(paste("Product", self$product_id, "updated."))
  return(self)
}

suspend_product <- function(self) UseMethod("suspend_product")

suspend_product.Product <- function(self) {
  self$status <- "Suspended"
  message(paste("Product", self$name, "suspended."))
  return(self)
}

activate_product <- function(self) UseMethod("activate_product")

activate_product.Product <- function(self) {
  self$status <- "Available"
  message(paste("Product", self$name, "activated."))
  return(self)
}

# Payment Class

Payment <- function(policyholder, product) {
  structure(list(
    policyholder = policyholder,
    product = product,
    due_date = Sys.Date() + 30,
    paid = FALSE
  ), class = "Payment")
}

# Process payment (returns updated objects)
process_payment <- function(self, amount) UseMethod("process_payment")

process_payment.Payment <- function(self, amount) {
  
  if (amount >= self$product$price) {
    self$paid <- TRUE
    self$policyholder$balance <- self$policyholder$balance + amount
    
    message(paste("Payment successful for", self$policyholder$name))
  } else {
    message("Insufficient payment.")
  }
  
  return(list(
    payment = self,
    policyholder = self$policyholder
  ))
}

# Reminder
send_reminder <- function(self) UseMethod("send_reminder")

send_reminder.Payment <- function(self) {
  message(paste(
    "Reminder: Payment due for",
    self$policyholder$name,
    "on",
    format(self$due_date)
  ))
  return(self)
}

# Penalty
apply_penalty <- function(self) UseMethod("apply_penalty")

apply_penalty.Payment <- function(self) {
  
  if (!self$paid) {
    penalty <- self$product$price * 0.1
    self$policyholder$balance <- self$policyholder$balance + penalty
    
    message(paste("Penalty of", penalty, "applied to", self$policyholder$name))
  }
  
  return(list(
    payment = self,
    policyholder = self$policyholder
  ))
}

# MAIN EXECUTION

# Create product
product1 <- Product(1, "Health Insurance", 500)
product1 <- create_product(product1)

# Create policyholders
p1 <- Policyholder(101, "Alice")
p2 <- Policyholder(102, "Bob")

p1 <- register(p1)
p2 <- register(p2)

# Assign products
p1 <- add_product(p1, product1)
p2 <- add_product(p2, product1)

# Payments
payment1 <- Payment(p1, product1)
payment2 <- Payment(p2, product1)

res1 <- process_payment(payment1, 500)
payment1 <- res1$payment
p1 <- res1$policyholder

res2 <- process_payment(payment2, 500)
payment2 <- res2$payment
p2 <- res2$policyholder

# Display results
display_details(p1)
display_details(p2)

